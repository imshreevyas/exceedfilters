<div class="breadcumb-wrapper style2 bg-smoke">
        <div class="container-fluid">
            <div class="breadcumb-content">
                <ul class="breadcumb-menu">
                    <li><a href="{{ env('APP_URL') }}">Home</a></li>
                    <li><a>Products</a></li>
                </ul>
            </div>
        </div>
    </div>