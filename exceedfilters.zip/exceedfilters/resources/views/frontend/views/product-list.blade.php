@extends('frontend.views.layout')

@section('content')

<!-- MAIN CONTENT -->
    <!--==============================
    Breadcumb
    ============================== -->
    @include('views.frontend.include.breadcrum')


<!-- MAIN CONTENT -->

@stop