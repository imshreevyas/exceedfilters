@extends('frontend.views.layout')

@section('content')

<!-- MAIN CONTENT -->
 
<!-- MAIN CONTENT -->

@stop