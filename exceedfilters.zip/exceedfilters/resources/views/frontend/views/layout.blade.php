@include('frontend.include.head')

@yield('content')

@include('frontend.include.footer')