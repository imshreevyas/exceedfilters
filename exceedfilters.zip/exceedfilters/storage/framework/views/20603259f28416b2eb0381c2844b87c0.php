<?php echo $__env->make('frontend.include.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Sub banner start -->
<div class="sub-banner">
    <div class="container">
        <div class="breadcrumb-area">
            <h1>Property Detail</h1>
            <ul class="breadcrumbs">
                <li><a href="index.html">Home</a></li>
                <li class="active">Property Detail</li>
                <li class="active"><?php echo e($propertyData['property_name']); ?></li>
            </ul>
        </div>
    </div>
</div>
<!-- Sub Banner end -->

<!-- Property details page start -->
<div class="property-details-page content-area-6">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <!-- Heading listing 3 start -->
                <div class="heading-listing-3">
                    <h2><?php echo e(isset($propertyData['property_name']) && !empty($propertyData['property_name']) ? $propertyData['property_name'] : ''); ?></h2>
                    <span class="rent">For <?php echo e(isset($propertyData['property_type']) && !empty($propertyData['property_type']) ? $propertyData['property_type'] : ''); ?></span>
                    <div class="clearfix"></div>
                    <div class="location clearfix"><i class="flaticon-pin"></i><?php echo e(isset($propertyData['location']) && !empty($propertyData['location']) ? $propertyData['location'] : ''); ?></div>
                    <h6 class="price"><?php echo e(isset($propertyData['sale_price']) && !empty($propertyData['sale_price']) ? $propertyData['sale_price'] : ''); ?></h6>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-8 col-md-12">
                <!-- main slider carousel items -->
                <div id="propertyDetailsSlider" class="carousel Property-details-sliders slide">
                    <div class="carousel-inner">
                        <?php
                            $property_assets_arr = json_decode($propertyData['property_assets'], true);
                            $i = 0;
                        ?>
                        <?php $__currentLoopData = $property_assets_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleAssets): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($singleAssets['type'] == 'image'): ?>
                            <div class="<?php echo e($i == 0 ? 'active' : ''); ?> item carousel-item" data-slide-number="<?php echo e($i); ?>">
                                <img src="<?php echo e(env('STORAGE_URL').$singleAssets['path']); ?>" class="img-fluid" alt="slider-listing">
                            </div>
                            <?php $i++; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php if(count($property_assets_arr)): ?>
                        <a class="carousel-control left clip-home" href="#propertyDetailsSlider" data-slide="prev"><i class="fa fa-angle-left"></i></a>
                        <a class="carousel-control right clip-home" href="#propertyDetailsSlider" data-slide="next"><i class="fa fa-angle-right"></i></a>
                        <?php endif; ?>
                    </div>
                    <!-- main slider carousel nav controls -->
                    <div class="smail-listing">
                        <ul class="carousel-indicators list-inline nav nav-justified">
                            <?php $i = 0; ?>
                            <?php $__currentLoopData = $property_assets_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleAssets): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($singleAssets['type'] == 'image'): ?>
                                <li class="list-inline-item <?php echo e($i == 0 ? 'active' : ''); ?>">
                                    <a id="carousel-selector-<?php echo e($i); ?>" class="selected" data-slide-to="<?php echo e($i); ?>" data-target="#propertyDetailsSlider">
                                        <img src="<?php echo e(env('STORAGE_URL').$singleAssets['path']); ?>" class="img-fluid" alt="smail-property">
                                    </a>
                                </li>
                                <?php $i++; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <!-- main slider carousel items -->
                </div>
                <!-- Property description start -->
                <?php if(isset($propertyData['property_details']) && !empty($propertyData['property_details'])): ?>
                <div class="property-description mb-40">
                    <h3 class="heading-2">
                        Description
                    </h3>
                    <p><?php echo e($propertyData['property_details']); ?></p>
                </div>
                <?php endif; ?>

                <!-- Floor plans start -->
                <div class="floor-plans mb-50">
                    <div id="faq" class="faq-accordion">
                        <h3 class="heading-2">
                            Other Details
                        </h3>
                        <div class="card">
                            <div class="card-header">
                                <a class="card-title" data-toggle="collapse" data-parent="#faq" href="#collapse1" aria-expanded="true">
                                    Details
                                </a>
                            </div>
                            <div id="collapse1" class="card-block collapse show">
                                <table>
                                    <tbody><tr>
                                        <td><strong>Property Type</strong></td>
                                        <td><strong>Sale Price</strong></td>
                                        <td><strong>Carpet</strong></td>
                                        <td><strong>Height</strong></td>
                                        <td><strong>Frontage</strong></td>
                                    </tr>
                                    <tr>
                                        <td>1600</td>
                                        <td>3</td>
                                        <td>2</td>
                                        <td>1</td>
                                        <td>1</td>
                                    </tr>
                                    </tbody>
                                </table>
                                <table>
                                    <tbody><tr>
                                        <td><strong>Self Contained</strong></td>
                                        <td><strong>Building Name</strong></td>
                                        <td><strong>Parking</strong></td>
                                    </tr>
                                    <tr>
                                        <td>1600</td>
                                        <td>3</td>
                                        <td>2</td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <?php 
                $propertyVideo = array_filter($property_assets_arr, function($item) {
                    if($item['type'] == 'video')
                        return $item;
                });
                ?>
                <!-- Video start -->
                <?php if(!empty($propertyVideo)): ?>
                <div class="video mb-50">
                    <h3 class="heading-2">
                        Property Video
                    </h3>
                    <iframe src="<?php echo e(env('STORAGE_URL').$propertyVideo['path']); ?>" allowfullscreen=""></iframe>
                </div>
                <?php endif; ?>

                <?php if(count($similar_property) > 0): ?>
                <?php
                    $slideToShow_count = 1;
                    if(count($similar_property) > 1){
                        $slideToShow_count = 2;
                    }
                ?>
                <!-- Similar property -->
                <div class="similar-property mb-20">
                    <h3 class="heading-2">Similar Property</h3>
                    <div class="container">
                        <div class="slick-slider-area">
                            <div class="row slick-carousel" data-slick='{"slidesToShow": <?php echo e($slideToShow_count); ?>, "responsive":[{"breakpoint": 1024,"settings":{"slidesToShow": <?php echo e($slideToShow_count); ?> }}, {"breakpoint": 768,"settings":{"slidesToShow": 1}}]}'>
                                <?php $__currentLoopData = $similar_property; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleProperty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $parking = $singleProperty['parking'];
                                    $furnished = $singleProperty['furnished'];
                                    $carpet = $singleProperty['carpet'];
                                    $property_img = '';
                                    $property_assets_arr = json_decode($singleProperty['property_assets'], true);
                                    if(count($property_assets_arr) > 0){
                                        foreach($property_assets_arr as $singleAssets){
                                            if($singleAssets['type'] == 'image'){
                                                $property_img = env('STORAGE_URL').$singleAssets['path'];
                                                break;
                                            }
                                        }
                                    }
                                ?>
                                <div class="slick-slide-item">
                                    <div class="property-box">
                                        <div class="property-thumbnail clip-home">
                                            <div class="listing-photo">
                                                <div class="now-open <?php echo e($singleProperty['property_type'] == 'Rental' ? 'new-color' : 'open-color'); ?>">For <?php echo e($singleProperty['property_type']); ?></div>
                                                <div class="tag"><?php echo e($singleProperty['sale_price']); ?></div>
                                                <img class="d-block w-100" src="<?php echo e($property_img); ?>" alt="listing-photo">
                                            </div>
                                        </div>
                                        <div class="detail">
                                            <h3 class="title">
                                                <a href="<?php echo e(env('APP_URL').'/'.$url_name.'/'.$singleProperty['property_uid']); ?>"><?php echo e($singleProperty['property_name']); ?></a>
                                            </h3>
                                            <p><i class="flaticon-pin"></i><?php echo e($singleProperty['location']); ?></p>
                                            <ul class="facilities-list clearfix">
                                                <li>
                                                    <i class="flaticon-bed"></i>
                                                    <span><?php echo e($parking); ?> Parking</span>
                                                </li>
                                                <li>
                                                    <i class="flaticon-bathtub"></i>
                                                    <span><?php echo e($furnished); ?></span>
                                                </li>
                                                <li>
                                                    <i class="flaticon-area"></i>
                                                    <span><?php echo e($carpet); ?></span>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="footer clearfix">
                                            <div class="pull-left days">
                                                <p><i class="flaticon-calendar"></i> <?php echo e((new Carbon\Carbon($singleProperty['created_at']))->diffForHumans()); ?></p>
                                            </div>
                                            <ul class="pull-right">
                                                <li><a href="tel:<?php echo e($settings['mobile']); ?>"><i class="flaticon-heart-1"></i></a></li>
                                                <li><a href="https://wa.me/?text=<?php echo e(urlencode('Hey, checkout this property from **Triniti Realty**! '.env('APP_URL').'/comercial-property/'.$singleProperty['property_uid'].'')); ?>"><i class="flaticon-share"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="slick-prev slick-arrow-buton">
                                <i class="fa fa-angle-left"></i>
                            </div>
                            <div class="slick-next slick-arrow-buton">
                                <i class="fa fa-angle-right"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>


            <div class="col-lg-4 col-md-12">
                <div class="sidebar-right">
                    <!-- Agent start -->
                    <div class="agent-3 widget">
                        <h3 class="sidebar-title">Contact Agent</h3>
                        <div class="s-border"></div>
                        <div class="m-border"></div>
                        <div class="media mb-4">
                            <a class="pr-3" href="agent-detail.html">
                                <img src="<?php echo e(env('ASSET_URL').'/assets/main-logo.png'); ?>" alt="agent-3" class="img-fluid">
                            </a>
                            <div class="media-body align-self-center">
                                <h5>
                                    <a href="agent-detail.html"><?php echo e(isset($settings['company_name']) ? $settings['company_name'] : ''); ?></a>
                                </h5>
                                <h6>Posted <?php echo e((new Carbon\Carbon($propertyData['created_at']))->diffForHumans()); ?></h6>
                            </div>
                        </div>
                        <div class="contact">
                            <ul>
                                <li>
                                    <i class="flaticon-pin"></i><?php echo e(isset($settings['address']) ? $settings['address'] : ''); ?>

                                </li>
                                <li>
                                    <i class="flaticon-mail"></i><a href="mailto:<?php echo e(isset($settings['emailid']) ? $settings['emailid'] : ''); ?>"><?php echo e(isset($settings['emailid']) ? $settings['emailid'] : ''); ?></a>
                                </li>
                                <li>
                                    <i class="flaticon-phone"></i><a href="tel:<?php echo e(isset($settings['mobile']) ? $settings['mobile'] : ''); ?>"><?php echo e(isset($settings['mobile']) ? $settings['mobile'] : ''); ?></a>
                                </li>
                                <li>
                                    <i class="flaticon-alarm"></i><?php echo e(isset($settings['opening_time']) ? $settings['opening_time'] : ''); ?> <?php echo e(isset($settings['closing_time']) ? 'To '.$settings['closing_time'] : ''); ?>

                                </li>
                                <li>
                                    <i class="flaticon-tag"></i><b>Open On:</b> <span><?php echo e(isset($settings['open_on']) ? $settings['open_on'] : ''); ?></a>
                                </li>
                            </ul>
                        </div>
                        <div class="button"><a href="tel:<?php echo e(isset($settings['mobile']) ? $settings['mobile'] : ''); ?>" class="btn btn-user button-theme">Call Now!</a></div>
                    </div>
                    <!-- Mortgage calculator start -->
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Property details page end -->

<?php echo $__env->make('frontend.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\trinitirealty\resources\views/frontend/views/property_detail.blade.php ENDPATH**/ ?>