<!DOCTYPE html>
<html lang="zxx">

<head>
    <title><?php echo e(isset($settings['title']) ? $settings['title'] : ''); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">

    <!-- External CSS libraries -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/animate.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/bootstrap-submenu.css')); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/bootstrap-select.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/magnific-popup.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/daterangepicker.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/leaflet.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/map.css')); ?>" type="text/css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/fonts/font-awesome/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/fonts/flaticon/font/flaticon.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/fonts/linearicons/style.css')); ?>">
    <link rel="stylesheet" type="text/css"  href="<?php echo e(asset('assets/frontend/css/jquery.mCustomScrollbar.css')); ?>">
    <link rel="stylesheet" type="text/css"  href="<?php echo e(asset('assets/frontend/css/dropzone.css')); ?>">
    <link rel="stylesheet" type="text/css"  href="<?php echo e(asset('assets/frontend/css/slick.css')); ?>">

    <!-- Custom stylesheet -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/style.css')); ?>">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="<?php echo e(asset('assets/frontend/css/skins/default.css')); ?>">

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Raleway:300,400,500,600,300,700">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Dosis%7CMontserrat:200,300,400,500,600,700,800,900%7CNunito+Sans:200,300,400,600,700,800,900">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/css/ie10-viewport-bug-workaround.css')); ?>">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script  src="<?php echo e(asset('assets/frontend/js/ie8-responsive-file-warning.js')); ?>"></script><![endif]-->
    <script  src="<?php echo e(asset('assets/frontend/js/ie-emulation-modes-warning.js')); ?>"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script  src="<?php echo e(asset('assets/frontend/js/html5shiv.min.js')); ?>"></script>
    <script  src="<?php echo e(asset('assets/frontend/js/respond.min.js')); ?>"></script>
    <![endif]-->
</head>
<body>
<div class="page_loader"></div>
<script>
    var ASSET_URL = "<?php echo e(env('ASSET_URL')); ?>";
</script>

<?php echo $__env->make('frontend.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\trinitirealty\resources\views/frontend/include/head.blade.php ENDPATH**/ ?>