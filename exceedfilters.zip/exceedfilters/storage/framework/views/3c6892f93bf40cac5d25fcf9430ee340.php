
    <!-- <div class="popup-search-box">
        <button class="searchClose"><img src="<?php echo e(asset('assets/frontend/img/icon/close.svg')); ?>" alt="img"></button>
        <form action="#">
            <input type="text" placeholder="Search Here..">
            <button type="submit"><img src="assets/img/icon/search-white.svg" alt="img"></button>
        </form>
    </div> -->

    <div class="sidemenu-wrapper">
        <div class="sidemenu-content">
            <button class="closeButton sideMenuCls"><img src="<?php echo e(asset('assets/frontend/img/icon/close.svg')); ?>" alt="icon"></button>
            <div class="widget footer-widget">
                <div class="widget-about">
                    <div class="footer-logo">
                        <a href="index.html"><img src="<?php echo e($settings['logo']); ?>" alt="Logo"></a>
                    </div>
                    <p class="about-text">We are digital agency that helps businesses develop immersive and engaging</p>
                    <div class="sidebar-wrap">
                        <h6><?php echo e($settings['address']); ?></h6>
                    </div>
                    <div class="sidebar-wrap">
                        <h6><a href="tel:<?php echo e($settings['mobile']); ?>"><?php echo e($settings['mobile']); ?> </a></h6>
                        <h6><a href="mailto:<?php echo e($settings['emailid']); ?>"><?php echo e($settings['emailid']); ?></a></h6>
                    </div>
                    <div class="social-btn style2">
                    <?php if(isset($settings['facebook']) && !empty($settings['facebook'])): ?>
                        <a href="<?php echo e($settings['facebook']); ?>">
                            <span class="link-effect">
                                <span class="effect-1"><i class="fab fa-facebook"></i></span>
                                <span class="effect-1"><i class="fab fa-facebook"></i></span>
                            </span>
                        </a>
                    <?php endif; ?>
                
                    <?php if(isset($settings['instagram']) && !empty($settings['instagram'])): ?>
                        <a href="<?php echo e($settings['instagram']); ?>">
                            <span class="link-effect">
                                <span class="effect-1"><i class="fab fa-instagram"></i></span>
                                <span class="effect-1"><i class="fab fa-instagram"></i></span>
                            </span>
                        </a>
                    <?php endif; ?>
                
                    <?php if(isset($settings['twitter']) && !empty($settings['twitter'])): ?>
                        <a href="<?php echo e($settings['twitter']); ?>">
                            <span class="link-effect">
                                <span class="effect-1"><i class="fab fa-twitter"></i></span>
                                <span class="effect-1"><i class="fab fa-twitter"></i></span>
                            </span>
                        </a>
                    <?php endif; ?>
                
                    <?php if(isset($settings['dribble']) && !empty($settings['dribble'])): ?>
                        <a href="<?php echo e($settings['dribble']); ?>">
                            <span class="link-effect">
                                <span class="effect-1"><i class="fab fa-dribbble"></i></span>
                                <span class="effect-1"><i class="fab fa-dribbble"></i></span>
                            </span>
                        </a>
                    <?php endif; ?>
                    </div>
                </div>
            </div>
            <!-- <div class="d-flex justify-content-end">
                <a href="contact.html" class="chat-btn gsap-magnetic">Let’s Talk with us</a>
            </div> -->
        </div>
    </div><?php /**PATH C:\xampp\htdocs\projects\exceedfilters\resources\views/frontend/include/sidebar.blade.php ENDPATH**/ ?>