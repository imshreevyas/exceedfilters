
<!-- Footer start -->
<footer class="footer">
    <div class="container footer-inner">
        <div class="row">
            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6">
                <div class="footer-item clearfix">
                    <img src="<?php echo e(env('ASSET_URL').'/assets/main-logo.png'); ?>" alt="<?php echo e(isset($settings['company_name']) ? $settings['company_name'] : ''); ?> logo" class="f-logo">
                    <div class="text">
                        <p><?php echo e(isset($settings['footer_description']) ? $settings['footer_description'] : ''); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                <div class="footer-item">
                    <h4>Contact Us</h4>
                    <div class="s-border"></div>
                    <div class="m-border"></div>
                    <ul class="contact-info">
                        <li>
                            <i class="flaticon-pin"></i><?php echo e(isset($settings['address']) ? $settings['address'] : ''); ?>

                        </li>
                        <li>
                            <i class="flaticon-mail"></i><a href="mailto:<?php echo e(isset($settings['emailid']) ? $settings['emailid'] : ''); ?>"><?php echo e(isset($settings['emailid']) ? $settings['emailid'] : ''); ?></a>
                        </li>
                        <li>
                            <i class="flaticon-phone"></i><a href="tel:<?php echo e(isset($settings['mobile']) ? $settings['mobile'] : ''); ?>"><?php echo e(isset($settings['mobile']) ? $settings['mobile'] : ''); ?></a>
                        </li>
                        <li>
                            <i class="flaticon-alarm"></i><?php echo e(isset($settings['opening_time']) ? $settings['opening_time'] : ''); ?> <?php echo e(isset($settings['closing_time']) ? 'To '.$settings['closing_time'] : ''); ?>

                        </li>
                        <li>
                            <i class="flaticon-tag"></i><b>Open On:</b> <span><?php echo e(isset($settings['open_on']) ? $settings['open_on'] : ''); ?></span>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-xl-2 col-lg-2 col-md-6 col-sm-6">
                <div class="footer-item">
                    <h4>Useful Links</h4>
                    <div class="s-border"></div>
                    <div class="m-border"></div>
                    <ul class="links">
                        <li>
                            <a href="<?php echo e(env('APP_URL').'/commercial-properties'); ?>">Compercial</a>
                        </li>
                        <li>
                            <a href="<?php echo e(env('APP_URL').'/residential-properties'); ?>">Residential</a>
                        </li>
                        <li >
                            <a href="tel:<?php echo e(isset($settings['mobile']) ? $settings['mobile'] : ''); ?>">Contact Agent!</a>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                <div class="footer-item clearfix">
                    <h4>Mobile Number</h4>
                    <div class="s-border"></div>
                    <div class="m-border"></div>
                    <div class="Subscribe-box">
                        <p>Your Number will receive daily new property listings!</p>
                        <form class="form-inline" action="#" method="GET">
                            <input type="text" class="form-control mb-sm-0" id="inlineFormInputName3" placeholder="Enter Mobile Number">
                            <button type="submit" class="btn"><i class="fa fa-paper-plane"></i></button>
                        </form>
                    </div>
                </div>
            </div> -->
        </div>
    </div>
</footer>
<!-- Footer end -->

<!-- Sub footer start -->
<div class="sub-footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6">
                <p class="copy">© <?php echo e(date('Y')); ?> <a href="<?php echo e(env('APP_URL')); ?>"><?php echo e(isset($settings['company_name']) ? $settings['company_name'] : ''); ?></a> All Rights Reserved.</p>
            </div>
            <?php if(isset($settings['facebook']) || isset($settings['twitter']) || isset($settings['instagram'])): ?>
            <div class="col-lg-6 col-md-6">
                <ul class="social-list clearfix">
                    <?php if(isset($settings['facebook'])): ?>
                    <li><a href="#" class="f-facebook-bg"><i class="fa fa-facebook"></i></a></li>
                    <?php endif; ?>
                    <?php if(isset($settings['twitter'])): ?>
                    <li><a href="#" class="f-twitter-bg"><i class="fa fa-twitter"></i></a></li>
                    <?php endif; ?>
                    <?php if(isset($settings['instagram'])): ?>
                    <li><a href="#" class="f-google-bg"><i class="fa fa-instagram"></i></a></li>
                    <?php endif; ?>
                </ul>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<!-- Sub footer end -->

<!-- Full Page Search -->

<script src="<?php echo e(asset('assets/frontend/js/jquery-2.2.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/js/bootstrap.min.js')); ?>"></script>
<script  src="<?php echo e(asset('assets/frontend/js/bootstrap-submenu.js')); ?>"></script>
<script  src="<?php echo e(asset('assets/frontend/js/rangeslider.js')); ?>"></script>
<script  src="<?php echo e(asset('assets/frontend/js/jquery.mb.YTPlayer.js')); ?>"></script>
<script  src="<?php echo e(asset('assets/frontend/js/bootstrap-select.min.js')); ?>"></script>
<script  src="<?php echo e(asset('assets/frontend/js/jquery.easing.1.3.js')); ?>"></script>
<script  src="<?php echo e(asset('assets/frontend/js/jquery.scrollUp.js')); ?>"></script>
<script  src="<?php echo e(asset('assets/frontend/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
<script  src="<?php echo e(asset('assets/frontend/js/leaflet.js')); ?>"></script>
<script  src="<?php echo e(asset('assets/frontend/js/leaflet-providers.js')); ?>"></script>
<script  src="<?php echo e(asset('assets/frontend/js/leaflet.markercluster.js')); ?>"></script>
<script  src="<?php echo e(asset('assets/frontend/js/moment.min.js')); ?>"></script>
<script  src="<?php echo e(asset('assets/frontend/js/daterangepicker.min.js')); ?>"></script>
<script  src="<?php echo e(asset('assets/frontend/js/dropzone.js')); ?>"></script>
<script  src="<?php echo e(asset('assets/frontend/js/slick.min.js')); ?>"></script>
<script  src="<?php echo e(asset('assets/frontend/js/jquery.filterizr.js')); ?>"></script>
<script  src="<?php echo e(asset('assets/frontend/js/jquery.magnific-popup.min.js')); ?>"></script>
<script  src="<?php echo e(asset('assets/frontend/js/jquery.countdown.js')); ?>"></script>
<script  src="<?php echo e(asset('assets/frontend/js/maps.js')); ?>"></script>
<script  src="<?php echo e(asset('assets/frontend/js/app.js')); ?>"></script>

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script  src="<?php echo e(asset('assets/frontend/js/ie10-viewport-bug-workaround.js')); ?>"></script>
<!-- Custom javascript -->
<script  src="<?php echo e(asset('assets/frontend/js/ie10-viewport-bug-workaround.js')); ?>"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\projects\trinitirealty\resources\views/frontend/include/footer.blade.php ENDPATH**/ ?>