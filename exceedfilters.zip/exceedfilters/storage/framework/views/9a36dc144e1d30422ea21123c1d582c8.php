<?php echo $__env->make('frontend.include.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Main Content -->
<div class="sub-banner">
    <div class="container">
        <div class="breadcrumb-area">
            <h1>Property List</h1>
            <ul class="breadcrumbs">
                <li><a href="<?php echo e(env('APP_URL')); ?>">Home</a></li>
                <li class="active"><?php echo e($url_name); ?></li>
            </ul>
        </div>
    </div>
</div>

<!-- Pages 404 start -->
<div class="pages-404">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="pages-404-inner">
                    <h1>Oops... Inavlid Property!</h1>
                    <p class="lead">Contact us now! for more other properties.</p>
                    <a href="tel:<?php echo e(isset($settings['mobile']) ? $settings['mobile'] : ''); ?>" class="btn border-thn">Call Now!</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Pages 404 2 end -->


<!-- Main Content -->

<?php echo $__env->make('frontend.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\trinitirealty\resources\views/frontend/views/errors/404.blade.php ENDPATH**/ ?>