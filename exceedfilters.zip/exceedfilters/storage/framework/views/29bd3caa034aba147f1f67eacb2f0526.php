<?php echo $__env->make('frontend.include.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Main Content -->

<!-- Banner start -->
<div class="banner">
    <div id="bannerCarousole" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item item-bg active clip-home">
                <img class="w-100 h-100" src="<?php echo e(asset('assets/frontend/img/banner/banner-2.jpg')); ?>" alt="banner">
                <div class="carousel-caption banner-slider-inner d-flex text-center clearfix">
                    <div class="bi-4">
                        <div class="container">
                            <div class="text-c">
                                <h1 class="b-text">Searching Your Dream Property?</h1>
                                <p><?php echo e(isset($settings['company_name']) ? $settings['company_name'] : ''); ?> has Best Property in mumbai! Contact US NOW!</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Banner end -->

<!-- Featured property strat -->
<?php if(count($residential_featured) > 0): ?>
<div class="featured-property content-area-14">
    <div class="container">
        <!-- Main title -->
        <div class="main-title">
            <h1>Residential Featured Property</h1>
        </div>
        <!-- Slick slider area start -->
        <div class="slick-slider-area">
            <?php
                $slideToShow_count = 1;
                if(count($residential_featured) > 1){
                    $slideToShow_count = 3;
                }
            ?>

            <div class="row slick-carousel" data-slick='{"slidesToShow": <?php echo e($slideToShow_count); ?>, "responsive":[{"breakpoint": 1024,"settings":{"slidesToShow": 2}}, {"breakpoint": 768,"settings":{"slidesToShow": 1}}]}'>
                    <?php $__currentLoopData = $residential_featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleResidential): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $property_img = '';
                        $resdential_property_assets = json_decode($singleResidential['property_assets'], true);
                        if(count($resdential_property_assets) > 0){
                            foreach($resdential_property_assets as $singleAssets){
                                if($singleAssets['type'] == 'image'){
                                    $property_img = env('STORAGE_URL').$singleAssets['path'];
                                    break;
                                }
                            }
                        }
                    ?>
                    <div class="slick-slide-item">
                        <div class="category">
                            <div class="category_bg_box cat-9-bg" style="background-image: url('<?php echo e($property_img); ?>');">
                                <div class="category-overlay">
                                    <div class="category-content">
                                        <h3 class="category-title">
                                            <a href="<?php echo e(env('APP_URL').'/residential-properties/'.$singleResidential['property_uid']); ?>"><?php echo e($singleResidential['property_name']); ?></a>
                                        </h3>
                                        <h4 class="category-subtitle"><i class="flaticon-pin"></i><?php echo e($singleResidential['location']); ?></h4>
                                        <ul class="facilities-list clearfix">
                                            <li>
                                                <i class="flaticon-car"></i><?php echo e($singleResidential['parking']); ?> Parking
                                            </li>
                                            <li>
                                                <i class="flaticon-bathtub"></i><?php echo e($singleResidential['floor']); ?> Floor
                                            </li>
                                            <li>
                                                <i class="flaticon-area"></i><?php echo e($singleResidential['carpet']); ?>

                                            </li>
                                        </ul>
                                    </div>
                                    <div class="now-open <?php echo e($singleResidential['property_type'] == 'Rental' ? 'new-color' : 'open-color'); ?>">For <?php echo e($singleResidential['property_type']); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
            <div class="slick-btn">
                <div class="slick-prev slick-arrow-buton-2 sab-4">
                    <i class="fa fa-angle-left"></i>
                </div>
                <div class="slick-next slick-arrow-buton-2 sab-3">
                    <i class="fa fa-angle-right"></i>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<!-- Featured property end -->

<!-- Why choose us strat -->
<div class="why-choose-us">
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-6 col-lg-5 col-md-12 photo clip-home"></div>
            <div class="col-xl-6 col-lg-7 col-md-12 align-self-center">
                <div class="service-section row wcu-2">
                    <div class="col-md-12">
                        <h1>What are you looking for?</h1>
                    </div>
                    <div class="col-md-6 col-sm-6">
                        <div class="media service-info">
                            <div class="media-left">
                                <i class="flaticon-architecture-and-city-1"></i>
                            </div>
                            <div class="media-body">
                                <h4 class="mt-0">Residentail</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6">
                        <div class="media service-info">
                            <div class="media-left">
                                <i class="flaticon-price"></i>
                            </div>
                            <div class="media-body">
                                <h4 class="mt-0">Commercial</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Why choose us end -->

<!-- Recently property start -->
<?php if(count($commercial_featured) > 0): ?>
<div class="recently-property content-area-16">
    <div class="container">
        <!-- Main title -->
        <div class="main-title">
            <h1>Commercial Property</h1>
        </div>
        <!-- Slick slider area start -->
        <div class="slick-slider-area">
            <?php
                $slideToShow_count = 1;
                if(count($commercial_featured) > 1){
                    $slideToShow_count = 3;
                }
            ?>
            <div class="row slick-carousel" data-slick='{"slidesToShow": <?php echo e($slideToShow_count); ?>, "responsive":[{"breakpoint": 1024,"settings":{"slidesToShow": 2}}, {"breakpoint": 768,"settings":{"slidesToShow": 1}}]}'>
                
                <?php $__currentLoopData = $commercial_featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleCommercial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $property_img = '';
                    $commercial_property_assets = json_decode($singleResidential['property_assets'], true);
                    if(count($commercial_property_assets) > 0){
                        foreach($commercial_property_assets as $singleAssets){
                            if($singleAssets['type'] == 'image'){
                                $property_img = env('STORAGE_URL').$singleAssets['path'];
                                break;
                            }
                        }
                    }
                ?>
                <div class="slick-slide-item">
                    <div class="property-box">
                        <div class="property-thumbnail clip-home">
                            <div class="property-photo">
                                <div class="now-open open-color">For <?php echo e($singleCommercial['property_type']); ?></div>
                                <div class="tag"><?php echo e($singleCommercial['sale_price']); ?></div>
                                <img class="d-block w-100" src="<?php echo e($property_img); ?>" alt="property-photo">
                            </div>
                        </div>
                        <div class="detail">
                            <h3 class="title">
                                <a href="<?php echo e(env('APP_URL').'/commercial-properties/'.$singleCommercial['property_uid']); ?>"><?php echo e($singleCommercial['property_name']); ?></a>
                            </h3>
                            <p><i class="flaticon-pin"></i><?php echo e($singleCommercial['location']); ?></p>
                            <ul class="facilities-list clearfix">
                                <li>
                                    <i class="flaticon-car"></i>
                                    <span><?php echo e($singleCommercial['parking']); ?> Parking</span>
                                </li>
                                <li>
                                    <i class="flaticon-architecture-and-city-1"></i>
                                    <span><?php echo e($singleCommercial['furnished']); ?></span>
                                </li>
                                <li>
                                    <i class="flaticon-area"></i>
                                    <span><?php echo e($singleCommercial['carpet']); ?></span>
                                </li>
                            </ul>
                        </div>
                        <div class="footer clearfix">
                            <div class="pull-left days">
                                <p><i class="flaticon-calendar"></i> <?php echo e((new Carbon\Carbon($singleCommercial['created_at']))->diffForHumans()); ?></p>
                            </div>
                            <ul class="pull-right">
                                <li><a href="tel:<?php echo e($settings['mobile']); ?>"><i class="flaticon-phone"></i></a></li>
                                <li><a href="https://wa.me/?text=<?php echo e(urlencode('Hey, checkout this property from **Triniti Realty**! '.env('APP_URL').'/comercial-property/'.$singleCommercial['property_uid'].'')); ?>"><i class="flaticon-share"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <div class="slick-prev slick-arrow-buton">
                <i class="fa fa-angle-left"></i>
            </div>
            <div class="slick-next slick-arrow-buton">
                <i class="fa fa-angle-right"></i>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<!-- Recently property end -->

<!-- Counters strat -->
<div class="counters">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="media counter-box">
                    <div class="icon">
                        <i class="flaticon-award"></i>
                    </div>
                    <div class="media-body align-self-center">
                        <h2 class="counter">60</h2>
                        <p>Residential Property Sold</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="media counter-box">
                    <div class="icon">
                        <i class="flaticon-project"></i>
                    </div>
                    <div class="media-body align-self-center">
                        <h2 class="counter">50</h2>
                        <p>Commercial Property Sold</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="media counter-box">
                    <div class="icon">
                        <i class="flaticon-user"></i>
                    </div>
                    <div class="media-body align-self-center">
                        <h2 class="counter">125</h2>
                        <p>Happy Clients</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="media counter-box">
                    <div class="icon">
                        <i class="flaticon-supermarket"></i>
                    </div>
                    <div class="media-body align-self-center">
                        <h2 class="counter">396</h2>
                        <p>Cups Of Cofee</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Counters end -->


<!-- Testimonial start -->
<!-- <div class="testimonial content-area-5 t-bg-color">
    <div class="">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="testimonial-inner">
                        <div class="main-title">
                            <h1>Testimonial</h1>
                        </div>
                        <div id="carouselExampleIndicators3" class="carousel slide" data-ride="carousel">
                            <ol class="carousel-indicators">
                                <li data-target="#carouselExampleIndicators3" data-slide-to="0" class="active"></li>
                                <li data-target="#carouselExampleIndicators3" data-slide-to="1" class=""></li>
                                <li data-target="#carouselExampleIndicators3" data-slide-to="2" class=""></li>
                            </ol>
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <div class="testimonial-info media">
                                        <a class="user-profile" href="agent-detail.html">
                                            <img src="img/avatar/avatar-1.jpg" alt="avatar" class="img-fluid">
                                        </a>
                                        <div class="media-body align-self-center">
                                            <h5>
                                                <a href="agent-detail.html">Anne Brady</a>
                                            </h5>
                                            <h6>Restaurant Owner</h6>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas in pulvinar neque. Nulla finibus lobortis pulvinar. Donec a consectetur nulla. Nulla posuere sapien vitae. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <div class="testimonial-info media">
                                        <a class="user-profile" href="agent-detail.html">
                                            <img src="img/avatar/avatar-2.jpg" alt="avatar" class="img-fluid">
                                        </a>
                                        <div class="media-body align-self-center">
                                            <h5>
                                                <a href="agent-detail.html">Eliane Perei</a>
                                            </h5>
                                            <h6>Web Developer</h6>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas in pulvinar neque. Nulla finibus lobortis pulvinar. Donec a consectetur nulla. Nulla posuere sapien vitae. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <div class="testimonial-info media">
                                        <a class="user-profile" href="agent-detail.html">
                                            <img src="img/avatar/avatar-3.jpg" alt="avatar" class="img-fluid">
                                        </a>
                                        <div class="media-body align-self-center">
                                            <h5>
                                                <a href="agent-detail.html">Maria Blank</a>
                                            </h5>
                                            <h6>Office Manager</h6>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas in pulvinar neque. Nulla finibus lobortis pulvinar. Donec a consectetur nulla. Nulla posuere sapien vitae. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> -->
<!-- Testimonial end -->

<!-- Main Content -->

<?php echo $__env->make('frontend.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\trinitirealty\resources\views/frontend/views/home.blade.php ENDPATH**/ ?>