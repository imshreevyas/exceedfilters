<!DOCTYPE html>
<html lang="en" class="light-style layout-menu-fixed" dir="ltr" data-theme="theme-default" data-assets-path="assets/"
    data-template="vertical-menu-template-free">

<head>
    <meta charset="utf-8" />
    <meta name="viewport"
        content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

    <title>Edit Product</title>
    <script src="https://cdn.ckeditor.com/ckeditor5/12.0.0/classic/ckeditor.js"></script>

    <meta name="description" content="" />

    <!-- Icons. Uncomment required icon fonts -->
    <?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            <!-- Menu -->

            
            <?php echo $__env->make('admin.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- / Menu -->

            <!-- Layout container -->
            <div class="layout-page">

            <?php echo $__env->make('admin.include.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- Content wrapper -->
                <div class="content-wrapper">

                    <!-- Content -->

                    <div class="container-xxl flex-grow-1 container-p-y">
                        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Products /</span>
                            Edit Product</h4>

                        <div class="row">
                            <div class="col-md-12">
                                <form id="editProduct">
                                    <div class="card mb-4">
                                        <h5 class="card-header">Product Details</h5>
                                        <!-- Account -->

                                        <div class="card-body">
                                            <div class="row">
                                                <div class="mb-3 col-md-4">
                                                    <label for="product_name" class="form-label">Select Category</label>
                                                    <select name="category_uid" class="form-control">
                                                        <?php if(count($categories) > 0): ?>
                                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($category['category_uid']); ?>" <?php echo e($category['category_uid'] == $product->category_uid ? 'selected' : ''); ?>><?php echo e($category['name']); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </select>
                                                </div>

                                                <div class="mb-3 col-md-4">
                                                    <label for="product_name" class="form-label">Product Name</label>
                                                    <input class="form-control" type="text" id="product_name"
                                                        name="product_name" value="<?php echo e($product->product_name); ?>"
                                                        placeholder="Enter Product Name" />
                                                </div>

                                            </div>
                                        </div>
                                    </div>

                                    <div class="card mb-4">
                                        <h5 class="card-header">Product Description</h5>
                                        <!-- Account -->

                                        <div class="card-body">
                                            <div class="row">
                                                <div class="mb-3 col-md-12" id="editor">
                                                    <textarea style="height:150px" class="form-control" type="text"
                                                        id="long_desc" name="long_desc" value="<?php echo e($product->long_desc); ?>"
                                                        placeholder="Enter Product Description"><?php echo e($product->long_desc); ?></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="mb-3 col-md-4">
                                            <button class="btn btn-primary btn-lg" type="submit"
                                                name="submitBtn">Edit Product</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- / Content -->

            <div class="content-backdrop fade"></div>
        </div>
        <!-- Content wrapper -->
    </div>
    <!-- / Layout page -->
    </div>

    <!-- Overlay -->
    <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->


    <!-- Core JS -->
    <?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
    
    ClassicEditor
    .create( document.querySelector( '#long_desc' ) )
    .catch( error => {
        console.error( error );
    } );

    $('#editProduct').on('submit', function(e) {
        e.preventDefault();
        axios.post(`${url}/admin/product/edit/<?php echo e($product['product_uid']); ?>`, new FormData(this)).then(function(response) {
            // handle success
            show_Toaster(response.data.message, response.data.type)
            if (response.data.type === 'success') {
                setTimeout(() => {
                    window.location.href = `${url}/admin/product/all`;
                }, 500);
            }
        }).catch(function(err) {
            show_Toaster(err.response.data.message, 'error')
        })
    });
    </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\projects\exceedfilters\resources\views/admin/product/editProduct.blade.php ENDPATH**/ ?>