<?php 

$currentPage = $paginator->currentPage();
$totalPage = $paginator->total();
$onFirtPage = $paginator->onFirstPage();
$lastPage = $paginator->lastPage();
$expectedLastPage = $currentPage + 3;
$lastLoopPage =  $expectedLastPage < $lastPage ? $expectedLastPage : ($expectedLastPage == $lastPage ? $lastPage : ($expectedLastPage > $lastPage ?  $lastPage : $expectedLastPage));
$paginationPath = $paginator->path();

?>

<div class="pagination-box text-center">
    <nav aria-label="Page navigation example">
        <ul class="pagination">
            <?php if($onFirtPage && $currentPage == 1): ?>
            <li class="page-item">
                <a class="page-link active" href="<?php echo e($paginator->previousPageUrl()); ?>">1</a>
            </li>
            <?php else: ?>
            <li class="page-item">
                <a class="page-link" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">Prev</a>
            </li>
            <?php endif; ?>

            <?php if($totalPage > 1): ?>
                <?php for($i=($currentPage == 1 ? $currentPage+1 : $currentPage);$i<=$lastLoopPage;$i++): ?>
                    <li class="page-item"><a class="page-link <?php echo e($i == $currentPage ? 'active' : ''); ?>" href="<?php echo e($paginationPath.'?page='.$i); ?>"><?php echo e($i); ?></a></li>
                <?php endfor; ?>


                <?php if($totalPage != $currentPage): ?>
                <li class="page-item">
                    <a class="page-link" href="<?php echo e($paginationPath.'?page='.($currentPage+1)); ?>">Next</a>
                </li>
                <?php endif; ?>
            <?php endif; ?>
            
        </ul>
    </nav>
</div><?php /**PATH C:\xampp\htdocs\projects\trinitirealty\resources\views/frontend/views/pagination.blade.php ENDPATH**/ ?>