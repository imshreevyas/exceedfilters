<?php echo $__env->make('frontend.include.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Main Content -->
<div class="sub-banner">
    <div class="container">
        <div class="breadcrumb-area">
            <h1>Property List</h1>
            <ul class="breadcrumbs">
                <li><a href="index.html">Home</a></li>
                <li class="active">Property List</li>
            </ul>
        </div>
    </div>
</div>

<div class="property-section ps-2 content-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <!-- Option bar start -->
                <div class="option-bar">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <h3>Showing 1-<?php echo e($properties->total()); ?> of <?php echo e(count($properties)); ?> Listings</h3>
                        </div>
                        
                    </div>
                </div>

                <?php if(count($properties) > 0): ?>
                    <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleProperties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php
                     
                        $property_img = '';
                        $property_assets_arr = json_decode($singleProperties['property_assets'], true);
                        if(count($property_assets_arr) > 0){
                            foreach($property_assets_arr as $singleAssets){
                                if($singleAssets['type'] == 'image'){
                                    $property_img = env('STORAGE_URL').$singleAssets['path'];
                                    break;
                                }
                            }
                        }
                        
                        $title = $singleProperties['property_name'];
                        $address = $singleProperties['location'];
                        $type = $singleProperties['property_type'];
                        $parking = $singleProperties['parking'];
                        $furnished = $singleProperties['furnished'];
                        $carpet = $singleProperties['carpet'];


                    ?>
                        <div class="property-box-2" >
                            <div class="row">
                                <div class="col-lg-4 col-md-5 col-pad">
                                    <div class="property-thumbnail">
                                        <a href="single-property.html" class="property-img">
                                            <img src="<?php echo e($property_img); ?>" alt="listing-photo-2" class="img-fluid">
                                            <div class="now-open <?php echo e($singleProperties['property_type'] == 'Rental' ? 'new-color' : 'open-color'); ?>">For <?php echo e($type); ?></div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-8 col-md-7 col-pad">
                                    <div class="detail align-self-center">
                                        <h3 class="title">
                                            <a href="<?php echo e(env('APP_URL').'/'.$url_name.'/'.$singleProperties['property_uid']); ?>"><?php echo e($title); ?></a>
                                        </h3>
                                        <p><i class="flaticon-pin"></i><?php echo e($address); ?></p>
                                        <ul class="facilities-list clearfix">
                                            <li>
                                                <i class="flaticon-car"></i>
                                                <span><?php echo e($parking); ?> Parking</span>
                                            </li>
                                            <li>
                                                <i class="flaticon-bathtub"></i>
                                                <span><?php echo e($furnished); ?></span>
                                            </li>
                                            <li>
                                                <i class="flaticon-area"></i>
                                                <span><?php echo e($carpet); ?></span>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="footer clearfix">
                                        <div class="pull-left days">
                                            <p><i class="flaticon-calendar"></i> <?php echo e((new Carbon\Carbon($singleProperties['created_at']))->diffForHumans()); ?></p>
                                        </div>
                                        <ul class="pull-right">
                                            <li><a href="tel:<?php echo e($settings['mobile']); ?>" tabindex="0"><i class="flaticon-phone"></i></a></li>
                                            <li><a href="https://wa.me/?text=<?php echo e(urlencode('Hey, checkout this property from **Triniti Realty**! '.env('APP_URL').'/comercial-property/'.$singleProperties['property_uid'].'')); ?>" tabindex="0"><i class="flaticon-share"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <!-- Page navigation start -->
                <?php echo e($properties->onEachSide(1)->links('frontend.views.pagination')); ?>

            </div>
        </div>
    </div>
</div>
<!-- Main Content -->

<?php echo $__env->make('frontend.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\trinitirealty\resources\views/frontend/views/property_listing.blade.php ENDPATH**/ ?>