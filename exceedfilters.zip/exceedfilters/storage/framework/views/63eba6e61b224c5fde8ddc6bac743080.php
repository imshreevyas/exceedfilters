

<?php $__env->startSection('content'); ?>

<div class="error-wrapper text-center">
    <div class="container">
        <img class="mb-50" src="assets/img/normal/404.png" alt="error">
        <h2>Look Like You’re Lost</h2>
        <p class="sec-text mb-30">The link you followed probably broken or the page has been removed</p>
        <a href="index.html" class="link-btn">
            <span class="link-effect">
                <span class="effect-1">back to home</span>
                <span class="effect-1">back to home</span>
            </span>
            <img src="assets/img/icon/arrow-left-top.svg" alt="icon">
        </a>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.views.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\exceedfilters\resources\views/frontend/views/errors/404.blade.php ENDPATH**/ ?>